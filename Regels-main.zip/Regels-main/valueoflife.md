# Value Of Life

➥ Value of life inhoud </b></br>
   - een leven in zuiderveen is waardevol dus dit mag niet zomaar worden beindigt door jezelf. Dit noemen wij No Value of Life en dit is tegen de regels van zuiderveen </br>
   - in een scenario waarin er een wapen op je wordt gericht moet je altijd luisteren doe je dit niet valt dit onder No Value of Life.</br>
   - Het zelf beindigen van je leven voor onnodige redenen is niet toegestaan! (denk hierbij aan: het niet luisteren als je wordt overvallen, het zelf springen van de dam af, uit een auto springen die hard rijdt.</br>

➥ Conclusie </b>
   - neem zo min mogelijk risico dat kan leiden tot je dood of ernstige verwondingen.</br>
   
➥ Enkele Scenario's waarin dit kan voortkomen.</b>
   - Wapen is staan blijven en luisteren, doe je dit niet : No Value of Life</br>
   - Sta je boven op de dam blijf dan staan en spring er niet van af spring je er wel van af : No Value of Life</br>
   - Word er iets aan je gevraagt terwijl je onderschot word gehouden werk dan gelijk mee en ga niet treuzelen : No Value of Life</br>
   - Rijd de auto boven de 80 KM/PU en je springt eruit valt dit onder : No Value of Life </br>
   - onnodig voor een auto gaan staan valt onder : No Value of Life . </br>
   - onnodig van een gebouw of brug afspringen valt onder : No Value of Life  . </br>
© 2020 ZuiderveenRP
