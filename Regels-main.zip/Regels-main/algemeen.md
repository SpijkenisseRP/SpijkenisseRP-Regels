# Algemene Regels

◦ <b>VDM</b> (Vehicle Deathmatch) ➥ Het doden van een persoon doormiddel van een auto, boot en/of helikopter is niet toegestaan.

◦ <b>RDM</b> (Random Deathmatch) ➥ Het doden van een persoon zonder voorafgaande roleplay (zoals: een verkeersongeluk, iemand uitschelden en 1 x per ongeluk slaan zijn hier voorbeelden van) is niet toegestaan.

◦ <b>Gta Drive Style</b> ➥ Het met hoge snelheden door de stad heen rijden, stunt jumps nemen, onrealistisch offroad rijden, rammen van andere voertuigen en met hoge snelheid met een lekke band rijden is niet toegestaan.

◦ <b>Karakter Breken</b> ➥ Het ooc gaan in een roleplay situatie is niet toegestaan. Als iemand dit doet probeer het scenario zo goed mogelijk te eindigen. 

◦ <b>Combat Loggen</b> ➥ Het verlaten van de server tijdens een scenario is niet toegestaan. Bedenk voordat je een scenario begint of je genoeg tijd hebt.

◦ <b>Combat Storing</b> ➥ Het bijvoorbeeld stallen van je voertuig midden in een actervolging of het niet meewerken bij een huiszoeking.

◦ <b>Scenario Verstoren</b> ➥ Het verstoren van scenario's is niet toegestaan. Bijvoorbeeld politie van hun werk afhouden of niet luisteren naar vorderingen. 

◦ <b>Racisme</b> ➥ Racisme om ras, huidskleur, religie etc is niet toegestaan. Het vals beschuldigen van racisme is ook niet toegestaan. 

◦ <b>Vluchten Voor Politie en/of Kmar</b> ➥ Als je vlucht voor politie/kmar moet je altijd een geldige reden hebben. Bij een staande houding mag de politie/kmar je niet zomaar fouilleren. Als je vlucht mogen ze dat natuurlijk wel doen.

◦ <b>Nieuwe Spelers</b> ➥ Ze zijn net nieuw in de stad. Laat hun eerst rustig de stad verkennen dus ontvoer ze niet gelijk etc.

◦ <b>Metagamen</b> ➥ Het buiten game verkregen informatie ingame gebruiken is niet toegestaan dus ook geen "bodycam" video's. 

◦ <b>Powergamen</b> ➥ Als je bijvoorbeeld iemand wilt ontvoeren en deze persoon werkt goed mee. Als je hem dan nog steeds neerschiet valt onder powergamen en dit is niet toegestaan.

◦ <b>Bugs</b> ➥ Het misbruiken van bugs en niet melden is niet toegestaan. Hier kan een <b>permanente</b> ban op staan.

◦ <b>Cheats</b> ➥ Het gebruik van hack/mods is niet toegestaan. Hier staat een <b>permanente</b> ban op.

◦ <b>Alt Accounts</b> ➥ Het gebruik van alt accounts is niet toegestaan. Hier kan een <b>permanente</b> ban op staan.

◦ <b>Crosshair</b> ➥ Het gebruik van een extern "richt puntje" is niet toegestaan. 
 
◦ <b>Soundboard/Voicechanger</b> ➥ Het gebruik van een soundboard/voicechanger is niet toegestaan.

◦ <b>Schelden Met Kanker</b> ➥ Het schelden met kanker is op geen enkele wijze toegestaan.

◦ <b>Dubbel Clannen</b> ➥ Het spelen in een andere stad terwijl je op deze stad een whitelisted job hebt is niet toegestaan.

◦ <b>Microfoon</b> ➥ Je moet een goed werkende microfoon hebben. Als je dit niet hebt is het niet toegestaan om in de stad te komen.

◦ <b>Kleding</b> ➥ Het dragen van overheidskleding of staff kleding is niet toegestaan. Als je dit wel doet kan hier een <b>permanente</b> ban op staan.

◦ <b>Aanrijding</b> ➥ Bij een aanrijding moet je de roleplay aangaan. Dus niet wegrijden als je dit wel doet wordt dit gezien als VDM. 

◦ <b>Chat</b> ➥ Het is niet toegestaan om voertuigen in Twitter en/of nieuws te adverteren. Dit mag alleen in het Autoscout-24 in discord.

◦ <b>Refunds</b> ➥ Voorwerpen worden niet gerefund zonder daadwerkelijk bewijs via een clip systeem zoals medal.

◦ <b>Green zones</b> ➥ In een green zone mag je niemand vermoorden/overvallen / Criminele activiteiten uitvoeren. Op de volgende locaties zijn greenzone: Politiebureau, ziekenhuis, Anwb Hq, Cardealer, Blokkenpark, Gemeentehuis en Casino.

◦ <b>IRL geld</b> ➥ Het is in geen enkele wijze toegestaan om diensten/spullen te verkopen voor IRL geld hier staat een permanente ban op.

© 2020 ZuiderveenRP
