# New Life Rule
➥ Werking van de New Life Rule is als volgt:
   - Je vergeet alles wat je hebt gezien in dit ''leven''</br>
   - Je mag niet meer deelnemen aan het scenario waarin je bent gestorven.</br>
   - Je veranderd je naam van je personage (/register).</br>
   
➥ Wanneer treedt de New Life Rule in </b>
   - Als je bent vermoord door een vuurwapen.</b></br>
   - Als je bent doodgestoken / geslagen.</b></br>
   - Als je geen bloed meer in je lichaam hebt.</b></br>
   - Als je dood word verklaard door een Ambulancier, Politieagent of een stafflid.</br>
   
➥ Wat weet je nog wel! </b> 
   - De contacten in je telefoon.</br>
   - ben je lid van een gang, dan weet je nog welke dit is.</br>
   - Heb je een overheidsbaan weet je ook nog wat je doet.</br>
   
➥ Politie New Life Rule </b>
   - Indien de politie dood wordt verklaard dient de agent in kwestie terug te gaan naar het hoofdkantoor waar hij weer mee mag deelnemen aan het scenario zonder gedachten aan wat er is gebeurd.

➥ Melding maken </b>
   - Het maken van een melding als je dood bent is verboden en zal bestraft worden.</br>
   - krijg je te maken met RDM of VDM en je hebt voldoende dashcam bewijs die kan worden getoond aan een staf-lid mag je een melding maken.

© 2020 ZuiderveenRP
