# Content

◦ <b>Opnames</b> ➥ Je mag opnames maken zonder een Streamer Rol. Als je die rol niet hebt is het niet toegestaan om reclame te maken voor je content. Deze rol kan je aanvragen via een ticket.

◦ <b>Tonen Van Locaties</b> ➥ Het tonen van gehieme locaties is niet toegestaan. Als je dit wel doet ben je direct je Streamer rol kwijt.

◦ <b>Plaatsen van content</b> ➥ Het plaatsen van ''kill montages'' in de discord onder het kopje Content is verboden!</br>

◦ <b>Streamsnipen</b> ➥ Streamsnipen is niet toegestaan. Hier zijn een paar voorbeelden van streamsnipen:
- Het achtervolgen van een streamer
- Persoon bij zijn irl naam noemen inplaats van zijn ingame naam
- Het opzoeken van de persoon via de stream
- In chat zijn irl naam noemen

◦ <b>Copyright</b> ➥ Er mag geen copyright content te zien zijn op jouw content.

© 2020 ZuiderveenRP
