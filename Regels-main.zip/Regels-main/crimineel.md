# Criminele Circuit

◦ <b>Scammen</b> ➥ Het scammen van spelers is toegestaan maar met grenzen: Je mag iemand maximaal voor €30,000 scammen, je mag <b>niet</b> scammen voor voertuigen. Als iemand €50,000 betaald en vervolgens €20,000 terug geeft telt dit ook als het breken van de <b>scam</b> regel.

◦ <b>Twitter</b> ➥ Twitter is geen illegaal platform waar jij spullen mag verkopen zoals: wapens, drugs locaties en andere criminele informatie. Deze regels gelden het zelfde voor het <b>kopen</b> van criminele informatie op het platform.


◦ <b>Ontvoeren</b> <br>
     ➥ Het ontvoeren van burgers is toegestaan zolang er een goeie RP, Of gedachte achter zit die kan worden uitgelegd door middel van een clip. <br>
     ➥ Het ontvoeren van burgers mag niet langer zijn dan 60 minuten! <br>
     ➥ Het ontvoeren van burgers mag niet als degene op dat moment op een greenzone staat!  Is deze hierheen gevlucht en dit staat op je clip mag je dit wel doen!<br>
     ➥ Voor het ontvoeren van burgers moet er minimaal 4 politie online zijn.<br>
    

◦ <b>Overvallen van burgers</b> <br>
     ➥ Het overvallen van iemand die een NON whitelisted job uitvoert is streng verboden (Kan je zien aan de Outfit!)<br> 
     ➥ Het overvallen van burgers in openbare plekken is niet toegestaan! (BPG appartementen,ziekhuis,PolitieBureau,BPG). <br>
     ➥ Het overvallen van burgers die minder dan 1 week in de stad zijn is streng verboden! <br>
     ➥ Het overvallen van burgers die in een greenzone staan mogen niet worden overvallen dit is streng verboden! <br>
     ➥ Na het overvallen van een burger mag je hem/haar niet vermoorden.<br>
     ➥ Het overvallen van burgers is maximaal voor een bedrag van €5,000.<br>
     ➥ Het overvallen van dezelfde burger is niet toegestaan.<br>
     ➥ Het overvallen van burgers mag altijd! Mits je je aan de boven geschreven regels houdt!  <br>
     
◦ <b>Let op!</b><br>
     ➥Bij het overvallen van burger zullen de spullen die zijn ingenomen door de overvaller wordt teruggegeven aan de die is overvallen! Worden er meerdere feiten            geconstateerd zullen deze worden opgeteld en leiden tot een hogere straf.<br>

◦ <b>Het vermoorden van burgers</b><br>
     ➥ Het vermoorden van burgers mag, mits er wordt voldaan aan de regels van het overvallen van burgers.<br>
     ➥ Er moet worden voldaan aan een duidelijk RP Scenario. (beoordeeld door een staflid)<br> 
     ➥ Het vermoorden van burgers is niet toegestaan op de volgende plekken:
        Blokkenpark garage, Ziekenhuis, Auto Dealer, Politiebureau, ANWB HQ, Casino. <br>
     ➥ Het vermoorden van hostages mag als het scenario escaleert anders is dit niet toegestaan.<br> 

◦ <b>Overval op een bank,juwelier of winkel</b> <br>
     ➥ Max overvallers bij een grote bank is 10. <br>
     ➥ Max overvallers bij een kleine bank of winkel is 5. <br>
     ➥ Max overvallers bij een Juwelier is 8. <br>
     ➥ Max hostages bij een kleine bank, juwelier of winkel is 5. <br>
     ➥ Max hostages bij een grote bank is 10.<br>
     ➥ De onderhandelaar mag niet worden gegijzeld of beschoten worden in onderhandeling.<br>
     ➥ Het onnodig doodschieten van hostages mag niet! <br>
     ➥ Vrienden als hostage nemen is ten strengste verboden.<br>
     ➥ Aantal politie online voor een kleine bank en winkel is 4.<br>
     ➥ Aantal politie online voor een grote bank is 7.<br>
     ➥ Aantal politie online voor een juwelier is 5.<br>
     
◦ <b>RolePlay tegen over de politie</b><br>
     ➥ Het schieten op politie mag in de volgende Scenario’s, Bank overval waarin de politie binnenvalt of schiet, In geval van nood (alleen waarschuwing schoten),           Als je een politie onder schot hebt en er komt back-up en het wordt gevaarlijk voor jou en je collega mag je schieten,onnodig schieten is een ban.<br> 
     ➥ Als je op een politie schiet probeer altijd eerst op de benen te schieten! Onnodig politie doodschieten is een ban <br>
     
◦ <b>Het ontvoeren van Politie</b><br>
     ➥ Het ontvoeren van politie mag pas als er 6 agenten in dienst zijn. <br>
     ➥ Het losgeld vragen voor een politie agent is toegestaan het maximale bedrag van dit bedraagt 50.000 euro. <br>
     ➥ Het meerdere malen op 1 dag een en dezelfde agent ontvoeren is niet toegestaan. <br>
     ➥ Het maximale agenten dat mag worden ontvoert per dag is 3. <br>
     
◦ <b>Wanneer mag je gefouilleerd worden</b><br>
     ➥ Als je een holster om hebt.<br>
     ➥ Als je vlucht voor de politie.<br>
     ➥ Preventief fouilleren mag wanner het dreigingsniveau 5 is.<br>
     ➥ Fouilleren mag als er een schietmelding in de omgeving is.<br>
     ➥ Fouilleren mag als ze je betrappen op illegale activiteiten.<br>
     ➥ Je mag NIET worden gefouilleerd als je een verkeersovertreding begaat.<br>

◦ <b>Vuurwapenwet</b> <br>
     ➥ Word er een mes op je gericht en sta je binnen Steekafstand werk je mee kan je wegrennen mag dat wel maar heb je t risico dat je wordt gestoken! <br>
     ➥ Als je wordt gestoken mag je niet meer RENNEN, je mag wel LOPEN! <br>
     ➥ Als er een Mes op je gericht staat en je zit in een Auto mag je doorrijden.<br>
     ➥ Als er een vuurwapen op je gericht staat dien je ten alle tijden mee te werken! Wegrennen of de desbetreffende persoon aanvallen is ten strengste verboden en           word de No Value of Life regel toegepast<br>
     ➥ Word er geen wapen gericht op jou of je collega’s en heeft hij of zij hem niet meer in zijn hand mag je je wapen trekken, mits je niet meer in het zicht van de        overvaller of politie bent, ben je in de minderheid is een wapen trekken een NO GO! <br>
    
◦ <b>Regels ten aanzien van auto gebruik</b> <br>
     ➥ Het pitten onder de 100 KM Per/Uur is toegestaan! Remt degene die wordt achtervolgd en de politieauto of normale auto's botst ertegenaan is dit toegestaan.<br> 
     ➥ Het pakken van een auto uit de garage in een achtervolging mag niet! Staat er ergens een vriend die je ophaalt is wel toegestaan! <br>
     ➥ Bij een Fatale klap of crash in een achtervolging blijf je in je auto zitten als er een Scenario uit voort kan komen! <br>
     
◦ <b>FAIL RP scenarios/situaties</b>     <br>
     ➥ Het vluchten nadat iemand je probeert te pitten, overvallen, kidnappen naar een greenzone is ten strengste verboden! <br>
     ➥  OOC praten in een scenario is ten strengste verboden <br>
     ➥  Iemand doodschieten zonder RP hierbij zal het gebruikte wapen worden ingenomen.<br>

◦ <b>Communicatie regels</b><br>
     ➥ Worden je Communicatie middelen afgepakt dien je jezelf te muten in discord hierbij zal ook je bodycam moeten worden afgesloten.<br>
     ➥ Praat je in je oortje zorg ervoor dat je dit ook ingame doet als er mensen in je buurt zijn. <br>
     ➥ Kijkt iemand mee op je telefoon dan mag je de politie niet bellen of sms’en.    <br>
     
◦ <b>Verboden Criminaliteit</b><br>
     ➥ Het maken van meth met 2 personen in 1 bus is ten strengste verboden en valt onder bug abuse.<br>
     ➥ Het geven van een ''vergeet pil'' na dat je een burger overvalt. (dit mag wel in de volgende scenario's, als een gangmember de gang verlaat of eruit word gekicked).<br>
     
◦ <b>Regels over de GangWar</b> <br>
     ➥ New Life rule in de gangwar betekend dat nadat je bent doodgeschoten ook niet meer mag meedoen aan t scenario en je ook je outfit moet veranderen.<br>
     ➥ Je bent verplicht om je eigen gang outfit te dragen, de outfit moet je ook toesturen aan de rivaliserende gangs.<br>
     ➥ De aanleiding van een gangwar moet worden besproken met een Admin +.<br>
     ➥ maximale tijd van een gangwar is : 12 uur.<br>
     ➥ alle normale regels gelden naast de gangwar ook.<br>
     ➥ In de gangwar zijn de volgende safe-zones : Alle Garages, Ziekenhuis, Anwb Hoofdkantoor, het campen van deze plekken is ook niet toegestaan.<br>
    
     


© 2020 ZuiderveenRP
